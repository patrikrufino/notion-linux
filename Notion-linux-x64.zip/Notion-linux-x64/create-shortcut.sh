#!/bin/bash

# Define o caminho para o executável e para o ícone
executable="/home/$USER/notion/Notion-linux-x64/Notion"
icon="/home/$USER/notion/icon.png"

# Define o nome do atalho
name="Notion"

# Cria o arquivo de desktop para o atalho
echo "[Desktop Entry]
Version=1.0
Type=Application
Name=${name}
Comment=My Notion Application
Icon=${icon}
Exec=${executable}
Path=/home/$USER/notion/Notion-linux-x64
Terminal=false
StartupNotify=false" > "${name}.desktop"

# Adiciona permissão de execução ao arquivo
chmod +x "${name}.desktop"

# Move o arquivo de desktop para a pasta de aplicativos do GNOME
mv "${name}.desktop" "$HOME/.local/share/applications/"

echo "Atalho criado com sucesso!"
